# Adds static blocks with free content

